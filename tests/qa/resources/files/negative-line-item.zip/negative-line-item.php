<?php
/**
 * Plugin Name: Negative Line Item
 * Description: QA only (PIWOO-842, Express EXP-20/EXP-46). Gives the cart line of "Mollie Simple Test Product 0.02" a price of -0.02, so that line's total is below zero. Pair it with a product of 1.00 to keep the order total above zero.
 */
defined( 'ABSPATH' ) || exit;

add_action(
	'woocommerce_before_calculate_totals',
	static function ( $cart ) {
		if ( ! $cart instanceof WC_Cart ) {
			return;
		}
		foreach ( $cart->get_cart() as $item ) {
			$product = $item['data'] ?? null;
			if ( $product instanceof WC_Product && $product->get_slug() === 'mollie-product-simple-002' ) {
				$product->set_price( -0.02 );
			}
		}
	},
	20,
	1
);
