<?php
/**
 * Plugin Name: Feature Flags
 * 
 * Description: Enable Pay by Klarna, Riverty, Billie.
 */
add_filter( 'inpsyde.feature-flags.mollie-woocommerce.klarna_payments_api', '__return_true' );

add_filter( 'inpsyde.feature-flags.mollie-woocommerce.riverty_payments_api', '__return_true' );

add_filter( 'inpsyde.feature-flags.mollie-woocommerce.billie_payments_api', '__return_true' );