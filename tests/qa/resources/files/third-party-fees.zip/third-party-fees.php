<?php
/**
 * Plugin Name: Third Party Fees
 * 
 * Description: Add a global negative fee of -5 € to all WooCommerce orders.
 */
function add_global_negative_fee( $cart ) {
    if ( WC()->cart && ! WC()->cart->is_empty() ) {
        // The third parameter (taxable) is set to false in this example
        //$cart->add_fee( __( 'Global Discount', 'your-textdomain' ), -5, false );
        $cart->add_fee( __( 'Test Fee', 'your-textdomain' ), 5, false );
        $cart->add_fee( __( 'Test Fee2', 'your-textdomain' ), 1, false );
    }
}
add_action( 'woocommerce_cart_calculate_fees', 'add_global_negative_fee', 10, 1 );