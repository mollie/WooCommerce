<?php
/**
 * Plugin Name: Enable Bizum
 * 
 * Description: Enable Bizum.
 */
add_filter('inpsyde.feature-flags.mollie-woocommerce.bizum_enabled', '__return_true');