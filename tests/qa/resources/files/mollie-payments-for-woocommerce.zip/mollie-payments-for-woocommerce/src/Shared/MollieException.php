<?php

declare (strict_types=1);
namespace Mollie\WooCommerce\Shared;

use Exception;
class MollieException extends Exception
{
}
