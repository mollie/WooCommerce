<?php
/**
 * Plugin Name: PIWOO-890 Order Received Probe
 *
 * Description: QA-only probe for PIWOO-890. Sets the X-QA-Order-Received-Hit
 * response header whenever WordPress considers the current request to be the
 * order-received (thank-you) page, using the 'wp' action - the same point in
 * the request lifecycle tracking plugins use to detect the thank-you page,
 * and earlier than 'template_redirect' where Mollie's own return-redirect
 * fires. Used to verify the order-received page is observed as the thank-you
 * page exactly once per order, not once per leg of the Mollie return redirect.
 * Deactivate/delete once PIWOO-890 is closed.
 */

add_action(
	'wp',
	function () {
		if ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) {
			header( 'X-QA-Order-Received-Hit: 1' );
		}
	}
);
