<?php
/**
 * Plugin Name: Negative 0.01 Fee
 * Description: QA only (Express EXP-56). Adds a fixed cart fee of -0.01. Copy of negative-12-fee from the PayPal Payments QA files, with an amount that fits cent prices.
 */
defined( 'ABSPATH' ) || exit;

add_action(
	'woocommerce_cart_calculate_fees',
	static function ( $cart ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return;
		}

		if ( ! $cart instanceof WC_Cart || $cart->is_empty() ) {
			return;
		}
		$cart->add_fee( 'negative001Fee', -0.01, false );
	},
	10,
	1
);
