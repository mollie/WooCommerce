<?php

declare (strict_types=1);
namespace Mollie\WooCommerce\Gateway\Refund;

use UnexpectedValueException;
class PartialRefundException extends UnexpectedValueException
{
}
