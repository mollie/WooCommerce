<?php
/**
 * Plugin Name: Disable nonce check
 */
add_filter( 'woocommerce_store_api_disable_nonce_check', '__return_true' );