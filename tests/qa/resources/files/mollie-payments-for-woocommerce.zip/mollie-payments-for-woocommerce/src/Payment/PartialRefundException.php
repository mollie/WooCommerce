<?php

declare (strict_types=1);
namespace Mollie\WooCommerce\Payment;

use UnexpectedValueException;
class PartialRefundException extends UnexpectedValueException
{
}
