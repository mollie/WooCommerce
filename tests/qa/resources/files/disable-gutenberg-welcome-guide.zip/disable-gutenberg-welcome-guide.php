<?php
/**
 * Plugin Name:	Disable Gutenberg Welcome Guide
 *
 * Description:	Disable the "Disable Welcome Messages" in the Gutenberg Editor.
 */
add_filter(
	'block_editor_settings_all',
	function (array $settings): array {
		$settings['welcomeGuide'] = false;
		return $settings;
	}
);