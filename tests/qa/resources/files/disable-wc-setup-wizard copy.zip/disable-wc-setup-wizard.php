<?php
/**
* Plugin Name: Disable WC Setup Wizard
 */
delete_transient('_wc_activation_redirect');
add_filter('woocommerce_enable_setup_wizard', '__return_false');