<?php

declare (strict_types=1);
namespace Mollie\WooCommerce\PaymentMethods\PaymentFieldsStrategies;

class DefaultFieldsStrategy implements \Mollie\WooCommerce\PaymentMethods\PaymentFieldsStrategies\PaymentFieldsStrategyI
{
    public function execute($gateway, $dataHelper)
    {
    }
    public function getFieldMarkup($gateway, $dataHelper)
    {
    }
}
